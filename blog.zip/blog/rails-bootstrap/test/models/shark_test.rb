require 'test_helper'

class SharkTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
