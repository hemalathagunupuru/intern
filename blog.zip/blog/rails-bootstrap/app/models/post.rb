class Post < ApplicationRecord
  belongs_to :shark
end
