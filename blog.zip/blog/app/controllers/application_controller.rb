class ApplicationController < ActionController::Base
    require 'will_paginate'
end
