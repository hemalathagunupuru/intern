class SessionController < ApplicationController
    before_action :authenticate_user!, except: [:index, :show]
    
   def create
      user = User.find_by(email: params[:user][:email])
      if user
        if user.valid_password?(params[:user][:password]) 
          sign_in_and_redirect user
        else
          flash[:error] =  "Please enter the valid password."
        end
      end
    end
  end