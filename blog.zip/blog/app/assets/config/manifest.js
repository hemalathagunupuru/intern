//= link_tree ../images
//= link_directory ../stylesheets .css
$(document).on("turbolinks:load", function() {
    let $authors = $("select#post_author_id").selectize({
      valueField: "id",
      labelField: "name",
      create: function(input, cb) {
        $.ajax({
          url: "/authors",
          method: "POST",
          dataType: "json",
          data: {
            company: { name: input }
          },
          success: function(res) {
            console.log(res);
            if (!res.errors) {
              cb({ id: res.id, name: res.name });
            }
          }
        });
      }
    });
  });
  