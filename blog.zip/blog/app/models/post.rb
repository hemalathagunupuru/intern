class Post
  include Mongoid::Document
  include Mongoid::Timestamps
  field :title, type: String
  field :genre, type: String
  field :description, type: String
  field :pages, type: Integer
  field :author_name, type: String
  validates :title, presence: true
  validates :genre, presence: true
  validates :description, presence: true
  validates :pages, presence: true
  belongs_to :author, :optional => true
  belongs_to :user, :optional => true
  validates_presence_of :author
end