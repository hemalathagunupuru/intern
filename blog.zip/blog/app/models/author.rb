class Author
  include Mongoid::Document
  include Mongoid::Timestamps
  field :name, type: String
  field :age, type: Integer
  field :details, type: String
  validates_uniqueness_of :name, presence: true
  validates :age, presence: true
  validates :details, presence: true
  has_many :posts, dependent: :destroy
  belongs_to :user, :optional => true
end