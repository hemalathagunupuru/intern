Rails.application.routes.draw do
  devise_for :users
  resources :shareds
  resources :authors
  resources :posts
  resources :devise
  resources :home
  resources :layouts
  resources :users
  root "home#index"
  get 'home/header'
  get '/home/hemalatha/project4/blog/app/views/home', to: 'home#index'
  get '/authors/:id/authors_posts', to:'authors#authors_posts', as: 'authors_posts'
  get '/authors/:id/authors_reply', to:'authors#authors_reply', as: 'authors_reply'
  # Define your application routes per the DSL in https://guides.rubyonrails.org/routing.html

  # Defines the root path route ("/")
  # root "articles#index"
  resources :authors do
    member do
      get :posts
    end
  end
end
