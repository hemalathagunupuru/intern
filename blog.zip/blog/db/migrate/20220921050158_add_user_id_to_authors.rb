class AddUserIdToAuthors < Mongoid::Migration
  def changes
    add_column :authors, :user_id, :integer
    add_index :authors, :user_id
  end
end
