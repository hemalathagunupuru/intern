require "test_helper"

class SharedTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
