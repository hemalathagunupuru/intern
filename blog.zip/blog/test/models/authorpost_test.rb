require "test_helper"

class AuthorpostTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
