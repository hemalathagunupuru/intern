require "application_system_test_case"

class SharedsTest < ApplicationSystemTestCase
  setup do
    @shared = shareds(:one)
  end

  test "visiting the index" do
    visit shareds_url
    assert_selector "h1", text: "Shareds"
  end

  test "should create shared" do
    visit shareds_url
    click_on "New shared"

    click_on "Create Shared"

    assert_text "Shared was successfully created"
    click_on "Back"
  end

  test "should update Shared" do
    visit shared_url(@shared)
    click_on "Edit this shared", match: :first

    click_on "Update Shared"

    assert_text "Shared was successfully updated"
    click_on "Back"
  end

  test "should destroy Shared" do
    visit shared_url(@shared)
    click_on "Destroy this shared", match: :first

    assert_text "Shared was successfully destroyed"
  end
end
