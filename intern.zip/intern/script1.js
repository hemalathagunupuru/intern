var form=document.getElementById("addform");
var listItem=document.getElementById("list");
form.addEventListener("submit",(e)=>{
	e.preventDefault();
	var newItem=document.getElementById("item").value;
	var li=document.createElement('li');
	li.className="list-group-item";
    var x = document.createElement("INPUT");
	li.innerHTML=newItem;
    x.setAttribute("type", "checkbox")
    li.prepend(x);
    listItem.prepend(li);
    var button=document.createElement('button');
	button.className="btn btn-danger float-right";
	button.innerHTML="X";
	li.appendChild(button);
	listItem.appendChild(li);
});
listItem.addEventListener('click',(e)=>{
	if(e.target.classList.contains('btn')){
		var li=e.target.parentElement;
		listItem.removeChild(li);
	}
})