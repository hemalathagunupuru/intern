<html>
<head>
</head>
<body>
	<h1> hi,welcome </h1>
	<p id="demo"> visit avanthi college </p>
	<button onclick="myfunction()">try it</button>
	<script>
		function myfunction()
		{
			let mono=document.getElementById("demo").innerHTML;
			document.getElementById("demo").innerHTML=
			text.replace(avanthi college,vcr park);
		}
	</script>
</body>
</html>
