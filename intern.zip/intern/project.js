<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title>
        simple To-do list
    </title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css
</head>
    <body>
        <div class="container my-5">
            <form id="addform">
              <div class="form-ground">
                  <input type="text" class="form-control" placeholder="Enter new items">
              </div>
              <button type="submit" class="btn btn-primary my-5">submit<button>
            </form>
             <ul class="list-group list-group-flush">
                <li class="list-group-item">Cras just odio</li>
                <li class="list-group-item">Dapibus ac facilicies in</li>
                <li class="list-group-item">morbi leo risus</li>
                <li class="list-group-item">porta ac consectetur ac</li>
                <li class="list-group-item">vestibulum at eros</li>
            </ul>
        </div>
    <script src="script.js"></script>
    </body>
    </html>