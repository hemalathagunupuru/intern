<script>
function check()
{
	document.getElementById('f1').innerHTML=document.myform.name.value;
}
<form name='myform'>
<h4>NAME</h4>
<input type='text' name='name' value=' '>
<p><input type'submit' onclick='check();return false'></p>
<p id='f1'></p>
<p id='f2'></p>